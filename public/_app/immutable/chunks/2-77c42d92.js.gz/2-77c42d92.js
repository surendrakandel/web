import{default as t}from"../components/pages/(admin)/admin/_layout.svelte-ef4a973e.js";export{t as component};
