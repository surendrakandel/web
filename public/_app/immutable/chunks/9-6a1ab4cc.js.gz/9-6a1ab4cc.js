import{default as t}from"../components/pages/(admin)/admin/feedback/_page.svelte-12bf84aa.js";export{t as component};
