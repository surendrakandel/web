import{default as t}from"../components/pages/(app)/login/_page.svelte-86ffc842.js";export{t as component};
