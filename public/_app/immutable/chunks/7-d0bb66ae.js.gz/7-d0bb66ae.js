import{default as t}from"../components/pages/(admin)/admin/claims/_page.svelte-41528cdf.js";export{t as component};
