import{default as t}from"../components/pages/(bol)/documents/manual/_imagepdf_/_page.svelte-792dc733.js";const e=!0;export{t as component,e as server};
