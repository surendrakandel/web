import{default as t}from"../components/pages/(app)/unsubscribe/_page.svelte-201ae304.js";export{t as component};
