import{default as t}from"../components/pages/(app)/reset-password/_page.svelte-f381b62a.js";export{t as component};
