import{_ as r}from"./_page-3ff6c81d.js";import{default as t}from"../components/pages/(bol)/documents/_bol_id_/_page.svelte-41344ffc.js";export{t as component,r as shared};
