import{default as t}from"../components/pages/(admin)/admin/quote/_page.svelte-2bbd6f0f.js";export{t as component};
