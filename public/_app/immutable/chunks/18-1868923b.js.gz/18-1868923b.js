import{default as t}from"../components/pages/(app)/confirm-email/inform/_page.svelte-3cf4095d.js";export{t as component};
