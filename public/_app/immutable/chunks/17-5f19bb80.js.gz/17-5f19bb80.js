import{_ as r}from"./_page-bac929ac.js";import{default as t}from"../components/pages/(app)/confirm-email/_page.svelte-dba6be85.js";export{t as component,r as shared};
