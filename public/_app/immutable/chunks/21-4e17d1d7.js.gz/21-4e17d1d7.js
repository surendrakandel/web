import{default as t}from"../components/pages/(app)/log-out/_page.svelte-4fec2eab.js";export{t as component};
