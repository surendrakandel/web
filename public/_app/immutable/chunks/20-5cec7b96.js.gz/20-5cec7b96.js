import{default as t}from"../components/pages/(app)/forgot-password/_page.svelte-794cbb70.js";export{t as component};
