import{default as t}from"../components/pages/(app)/test/_page.svelte-409a9694.js";export{t as component};
