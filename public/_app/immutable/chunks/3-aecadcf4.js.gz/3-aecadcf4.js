import{default as t}from"../components/pages/(app)/_layout.svelte-923374e1.js";export{t as component};
