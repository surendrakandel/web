import{default as t}from"../components/pages/(admin)/admin/settings/_page.svelte-1f1f36a1.js";export{t as component};
