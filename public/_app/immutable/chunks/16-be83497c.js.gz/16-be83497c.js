import{default as t}from"../components/pages/(app)/about/_page.svelte-012d6120.js";export{t as component};
