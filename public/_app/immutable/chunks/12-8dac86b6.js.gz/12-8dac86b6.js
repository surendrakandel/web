import{default as t}from"../components/pages/(admin)/admin/rates/details/_page.svelte-586da941.js";export{t as component};
