import{default as t}from"../components/pages/(app)/unauthorized/_page.svelte-30daa019.js";export{t as component};
