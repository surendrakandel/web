import{default as t}from"../components/pages/(admin)/admin/track/_page.svelte-bee8fc1e.js";export{t as component};
