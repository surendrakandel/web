function t(e){return new Promise(s=>setTimeout(s,e))}export{t as s};
