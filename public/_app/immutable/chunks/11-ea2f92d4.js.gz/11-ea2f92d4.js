import{default as t}from"../components/pages/(admin)/admin/rates/_page.svelte-c8bd3294.js";export{t as component};
