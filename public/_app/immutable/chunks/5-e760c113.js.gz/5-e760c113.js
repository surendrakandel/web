import{default as t}from"../components/pages/(bol)/_layout.svelte-b632ac90.js";export{t as component};
