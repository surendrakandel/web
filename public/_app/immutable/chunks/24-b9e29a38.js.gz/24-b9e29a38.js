import{default as t}from"../components/pages/(app)/sign-up/_page.svelte-9709d073.js";export{t as component};
