import{default as t}from"../components/pages/(admin)/admin/_page.svelte-6c981bc2.js";export{t as component};
