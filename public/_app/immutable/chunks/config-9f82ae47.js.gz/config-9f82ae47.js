const t="http://127.0.0.1:8090/",s="http://127.0.0.1:3000/";export{t as B,s as F};
