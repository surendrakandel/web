import{default as t}from"../components/pages/(app)/contact/_page.svelte-ff027f02.js";export{t as component};
