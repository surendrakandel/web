import{default as t}from"../components/pages/(app)/_error.svelte-3e88ac0c.js";export{t as component};
