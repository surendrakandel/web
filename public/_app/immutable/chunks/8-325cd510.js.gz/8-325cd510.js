import{default as t}from"../components/pages/(admin)/admin/documents/_page.svelte-83b23e54.js";export{t as component};
