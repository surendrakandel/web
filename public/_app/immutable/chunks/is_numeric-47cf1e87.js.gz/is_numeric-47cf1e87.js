function i(e){return typeof e!="string"?!1:!isNaN(parseInt(e))&&!isNaN(parseFloat(e))}export{i};
