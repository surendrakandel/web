import{default as t}from"../components/pages/(app)/_page.svelte-b0d65cf7.js";export{t as component};
