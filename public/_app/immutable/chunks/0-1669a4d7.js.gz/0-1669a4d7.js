import{default as t}from"../components/layout.svelte-19f68276.js";export{t as component};
