import"./navigation-6a7bdca7.js";function n(o){var s;((s=o==null?void 0:o.response)==null?void 0:s.status)<500,console.log("handleAxiosError: ",o)}export{n as h};
