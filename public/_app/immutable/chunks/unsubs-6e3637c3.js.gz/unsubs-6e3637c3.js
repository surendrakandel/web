import{w as s}from"./index-c7174afa.js";let r=s([]);export{r as u};
