import{default as t}from"../components/error.svelte-041ca5b8.js";export{t as component};
