import"../../../../../chunks/config-9f82ae47.js";import{l as t}from"../../../../../chunks/_page-3ff6c81d.js";import"../../../../../chunks/JsBarcode-9ea5a7e6.js";export{t as load};
